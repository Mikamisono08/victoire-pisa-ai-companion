# Victoire Pisa AI Companion v1

## Cara mencoba di HP Android
1. Ekstrak ZIP ini.
2. Cara termudah: unggah folder ke layanan hosting statis seperti GitHub Pages atau Netlify, lalu buka tautannya di Chrome.
3. Untuk tes offline sederhana, buka `index.html` melalui editor/aplikasi yang mendukung preview HTML. Beberapa fitur browser seperti notifikasi mungkin tidak tersedia saat dibuka sebagai file lokal.
4. Dari menu Chrome, pilih **Tambahkan ke layar utama** bila situs sudah di-host.

## Yang sudah ada
- UI responsif untuk HP
- Tampilan karakter sementara berbasis CSS
- Chat demo dengan respons lokal
- Mode Companion, Focus, Playful, Silent
- Pengingat timer selama halaman tetap terbuka

## Batasan penting
- Belum terhubung ke Gemini atau API AI.
- Karakter yang terlihat sekarang adalah placeholder, bukan model resmi Victoire Pisa.
- Pengingat timer tidak dijamin berjalan setelah browser ditutup.
- Belum ada overlay di atas aplikasi Android lain, layanan latar belakang, mikrofon, atau suara TTS.
- Jangan menaruh API key di JavaScript frontend. Saat menambahkan AI API, gunakan backend/proxy agar kunci tidak terekspos.

## Langkah pengembangan berikutnya
1. Ganti placeholder dengan aset karakter yang kamu punya izin gunakan.
2. Tambahkan backend kecil untuk panggilan AI.
3. Tambahkan TTS dan input suara dengan izin pengguna.
4. Buat aplikasi Android native untuk notifikasi terjadwal dan overlay yang meminta izin secara jelas.
