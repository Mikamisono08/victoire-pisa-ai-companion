const messages = document.querySelector("#messages");
const input = document.querySelector("#chatInput");
let mode = "companion";
const modeNames = {companion:"Companion",focus:"Focus",playful:"Playful",silent:"Silent"};
const responses = {
  companion: ["Siap, Trainer. Kita kerjakan pelan-pelan, satu langkah dulu. 💗","Aku di sini buat menemani. Apa yang ingin kamu lakukan sekarang?","Kita bisa mulai dari tugas yang paling kecil supaya terasa lebih ringan."],
  focus: ["Mode fokus aktif. Pilih satu tugas, lalu kerjakan selama 15 menit tanpa pindah-pindah.","Baik, Trainer. Kita tentukan target kecil yang bisa selesai sekarang.","Aku akan mengurangi obrolan. Kalau butuh bantuan, panggil saja."],
  playful: ["Trainer, jangan cuma menatap layar. Pilih misi kita berikutnya! ✨","Pisa siap bertugas! Tapi strategi dulu, asal gas nanti malah muter-muter.","Aku punya firasat hari ini cocok untuk menaklukkan satu tugas kecil. Gas?"],
  silent: ["Mode hening aktif. Aku akan menjawab saat kamu mengirim pesan, tanpa sapaan spontan. 🌙"]
};
function addMessage(text, who="pisa"){
  const el=document.createElement("div"); el.className=`msg ${who}`; el.textContent=text;
  messages.appendChild(el); messages.scrollTop=messages.scrollHeight;
}
function reply(text){
  const t=text.toLowerCase();
  if(/uma musume|育成|support card|supoka|training|latihan/.test(t)) return "Siap bahas Uma Musume, Trainer! Kirim nama karakter, skenario, dan support card yang dipakai. Aku bisa bantu menyusun strategi, tetapi hasil rating tidak bisa dijamin.";
  if(/istirahat|capek|lelah|minum|air/.test(t)) return "Boleh, Trainer. Coba berhenti sebentar, minum air jika perlu, lalu kembali saat sudah siap. Mau pasang pengingat?";
  if(/fokus|belajar|proyek|kerja|tugas/.test(t)) return "Misi kecil dimulai! Pilih satu hal yang paling penting, kerjakan 15 menit, lalu evaluasi. Apa tugas pertamamu?";
  if(/halo|hai|pisa|hei/.test(t)) return "Hai, Trainer! 💗 Aku masih versi prototipe lokal. Nanti kita sambungkan otak AI supaya obrolannya lebih fleksibel.";
  return (responses[mode]||responses.companion)[Math.floor(Math.random()*(responses[mode]||responses.companion).length)] + "\n\nCatatan: ini balasan demo lokal, belum memakai model AI.";
}
document.querySelector("#chatForm").addEventListener("submit",e=>{
  e.preventDefault(); const text=input.value.trim(); if(!text)return;
  addMessage(text,"user"); input.value="";
  setTimeout(()=>addMessage(reply(text)),250);
});
document.querySelectorAll("[data-prompt]").forEach(b=>b.addEventListener("click",()=>{input.value=b.dataset.prompt;document.querySelector("#chatForm").requestSubmit()}));
document.querySelectorAll("[data-mode]").forEach(b=>b.addEventListener("click",()=>{
  mode=b.dataset.mode;
  document.querySelectorAll("[data-mode]").forEach(x=>x.classList.toggle("selected",x===b));
  document.querySelector("#modeLabel").textContent="Mode: "+modeNames[mode];
  document.querySelector("#greeting").textContent=({companion:"Trainer, aku siap menemani!",focus:"Fokus dulu, Trainer!",playful:"Ayo pilih misi, Trainer!",silent:"Mode hening aktif 🌙"})[mode];
  document.querySelector("#subGreeting").textContent=({companion:"Kita jalani satu langkah pada satu waktu.",focus:"Aku akan meminimalkan gangguan saat kamu bekerja.",playful:"Aku akan lebih aktif, tetapi tetap ada batasnya.",silent:"Aku tidak akan memulai sapaan selama mode ini aktif."})[mode];
  addMessage("Mode diubah ke "+modeNames[mode]+".");
}));
const reminders=[];
document.querySelector("#reminderForm").addEventListener("submit",e=>{
  e.preventDefault();
  const text=document.querySelector("#reminderText").value.trim();
  const minutes=Number(document.querySelector("#reminderMinutes").value);
  if(!text||!Number.isFinite(minutes)||minutes<1)return;
  const id=Date.now();
  const timer=setTimeout(()=>{
    if("Notification" in window && Notification.permission==="granted") new Notification("Victoire Pisa mengingatkan", {body:text});
    addMessage("⏰ Pengingat, Trainer: "+text);
    const item=reminders.find(r=>r.id===id); if(item)item.done=true;
    renderReminders();
  },minutes*60000);
  reminders.push({id,text,minutes,timer,done:false});
  document.querySelector("#reminderText").value="";
  document.querySelector("#reminderStatus").textContent="Pengingat dipasang. Biarkan halaman tetap terbuka agar timer berjalan.";
  if("Notification" in window && Notification.permission==="default") Notification.requestPermission();
  renderReminders();
});
function renderReminders(){
 const box=document.querySelector("#reminderList"); box.replaceChildren();
 reminders.forEach(r=>{
  const row=document.createElement("div");row.className="reminder-item";
  const label=document.createElement("span");label.textContent=`${r.done?"✓":"⏳"} ${r.text} · ${r.done?"selesai":r.minutes+" menit"}`;
  row.appendChild(label);
  if(!r.done){const cancel=document.createElement("button");cancel.textContent="Batalkan";cancel.onclick=()=>{clearTimeout(r.timer);r.done=true;renderReminders()};row.appendChild(cancel)}
  box.appendChild(row);
 });
}